
#ifndef __ASM_ARCH_MSM_SDCC_H
#define __ASM_ARCH_MSM_SDCC_H

int is_svlte_type_mmc_card(struct mmc_card *);

#endif  /* __ASM_ARCH_MSM_SDCC_H */

